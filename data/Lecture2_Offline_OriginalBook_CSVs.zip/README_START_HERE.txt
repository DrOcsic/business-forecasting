Business Forecasting — Lecture 2 — original book data

All four CSVs were copied byte-for-byte from the user-provided book data archive.
No observations were created, replaced, resampled or downloaded.

Files needed by the Colab notebook:
- global_economy.csv
- aus_retail.csv
- us_employment.csv
- aus_production.csv

How to use:
1. Open Lecture2_Colab_BookData_Detailed_StudentGuide.ipynb in Google Colab.
2. Run cells from the beginning.
3. When the upload box appears, upload THIS ZIP as one file.
   Alternatively, open this ZIP on your computer and upload all four CSVs together.
4. Continue running cells from top to bottom. No internet data download is required.

Note: the book files are historical datasets.
