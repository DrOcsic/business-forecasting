Business Forecasting - Week 3 data files

These CSV files are the only data files used in the Week 3 Colab notebook.

1. aus_airpassengers.csv
   Annual Australian air passenger data used to demonstrate variance-stabilizing transformations.

2. aus_production.csv
   Quarterly Australian production data. The Beer series is used for summary statistics and forecast-error examples.

3. us_employment.csv
   Monthly US employment data. The Retail Trade series is used for ACF, PACF, STL decomposition, feature strength and diagnostic examples.

4. aus_retail.csv
   Included as an additional original textbook dataset for student practice and consistency with the course data package.

Students may upload either this ZIP file or the CSV files individually in Google Colab.
